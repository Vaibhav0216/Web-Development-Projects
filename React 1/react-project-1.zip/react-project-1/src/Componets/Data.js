let movies = [
    {
      name: "loki",
      des:
        "lor jwehdub34grdy ge3dy1e3 edyg d2ygwed 2e3d2uewgd2y3d etgdywskqnasjij1a kqk   mqzkamsmem",
      image: "img/slide1.png"
    },
    {
      name: "falcon and winter solider",
      des:
        "lor jwehdub34grdy ge3dy1e3 edyg d2ygwed 2e3d2uewgd2y3d etgdywskqnasjij1a kqk   mqzkamsmem",
      image: "img/slide2.png"
    },
    {
      name: "wanda vision",
      des:
        "lor jwehdub34grdy ge3dy1e3 edyg d2ygwed 2e3d2uewgd2y3d etgdywskqnasjij1a kqk   mqzkamsmem",
      image: "img/slide3.png"
    },
    {
      name: "raya and last dragon",
      des:
        "lor jwehdub34grdy ge3dy1e3 edyg d2ygwed 2e3d2uewgd2y3d etgdywskqnasjij1a kqk   mqzkamsmem",
      image: "img/slide4.png"
    },
    {
      name: "luca",
      des:
        "lor jwehdub34grdy ge3dy1e3 edyg d2ygwed 2e3d2uewgd2y3d etgdywskqnasjij1a kqk   mqzkamsmem",
      image: "img/slide5.png"
    }
   ];

  export default movies;