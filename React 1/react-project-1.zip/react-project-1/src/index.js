import React from 'react';
import ReactDOM from 'react-dom';
// import Slide from './Componets/Slide.js';
import movies from "./Componets/Data.js";
import Navbar from './Componets/Navbar.js';
import './Style.css';

// console.log(movies[0]);  
function Card(props){
  return(<>
      <div className="caraousel-container">
        <div className="caraousel">
         <div className="slider">
          <div className="slide-content">
           <h1 className="movie-title">{props.names}</h1>
           <p className="movie-des">
             {props.des}
           </p>
          </div>
        <img src={props.poster} alt="" />
      </div> 
    </div>
  </div>
  </>);
}

ReactDOM.render(
  <>
    <Navbar/>
    <Card names={movies[0].name} des={movies[0].des} poster = {movies[0].image}/>
    <Card names={movies[1].name} des={movies[1].des} poster = {movies[1].image}/>
    <Card names={movies[2].name} des={movies[2].des} poster = {movies[2].image}/>
    <Card names={movies[3].name} des={movies[3].des} poster = {movies[3].image}/>
    <Card names={movies[4].name} des={movies[4].des} poster = {movies[4].image}/>
  </>,
  document.getElementById("root")
);
