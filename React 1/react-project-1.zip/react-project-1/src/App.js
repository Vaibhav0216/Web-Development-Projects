import react from "react";
const  app = () =>{
  retrun (<>
  <h1>hellow world</h1>
  <p>hjadhsjkah</p>
  </>);
}

export default app;