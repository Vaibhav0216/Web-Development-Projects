import React from 'react';
import ReactDOM from 'react-dom';
import Slide from './Componets/Slide.js';
// import movies from "./Componets/Data.js";
import Navbar from './Componets/Navbar.js';
import './Style.css';

ReactDOM.render(
  <>
    <Navbar/>
    <Slide/>
  </>,
  document.getElementById("root")
);
